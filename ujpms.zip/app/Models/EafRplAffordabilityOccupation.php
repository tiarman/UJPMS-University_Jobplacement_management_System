<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EafRplAffordabilityOccupation extends Model
{
    use HasFactory;

    protected $table = 'eaf_rpl_affordability_occupations';
    protected $fillable = [

    ];
}
