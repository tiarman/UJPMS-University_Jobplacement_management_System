<?php

namespace App\Http\Controllers;

use App\Helper\CustomHelper;
use App\Helper\RedirectHelper;
use App\Models\District;
use App\Models\Division;
use App\Models\Institute;
use App\Models\InstituteType;
use App\Models\Semester;
use App\Models\Technology;
use App\Models\Upazila;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;

class MahirController extends Controller {

}
